from django.shortcuts import render

tickets = [
	{
		'UserName': 'Jack',
		'UserNumber': 'n0799672',
		'OrderInQueue': '1'
	},
	{
		'UserName': 'Jack2',
		'UserNumber': 'n0799673',
		'OrderInQueue': '2'
	
	},
	{
		'UserName': 'Jack3',
		'UserNumber': 'n0799674',
		'OrderInQueue': '3'
	}

]





# Create your views here.
def login(request):
    return render(request, 'mainSite/login.html')
	
	
	
def operator(request):
    return render(request, 'mainSite/operator.html')
	
def QueueView(request):
	context = {
	'tickets': tickets
	}
	return render(request, 'mainSite/QueueView.html',context)
