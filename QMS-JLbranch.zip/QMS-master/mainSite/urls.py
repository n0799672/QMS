from django.urls import path
from . import views

urlpatterns = [
    path('', views.login, name ='mainSite-login'),
	path('operator/', views.operator, name ='mainSite-operator'),
	path('QueueView/', views.QueueView, name ='mainSite-QueueView'),
	
]
